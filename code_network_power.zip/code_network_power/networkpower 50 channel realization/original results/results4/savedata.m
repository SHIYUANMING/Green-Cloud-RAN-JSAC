Q=[8:-2:0]';  %QoS in dB

save('totalpower4.mat','TotalPower_CBF_temp4','TotalPower_IRLSAlternating_temp4','TotalPower_IRLSAlternating_2_temp4','TotalPower_Baseline_temp4','TotalPower_Exhaustive_temp4');

save('transmitpower4.mat','TransmitPower_CBF_temp4','TransmitPower_IRLSAlternating_temp4','TransmitPower_IRLSAlternating_2_temp4','TransmitPower_Baseline_temp4','TransmitPower_Exhaustive_temp4');

save('activerrh4.mat','A_number_IRLSAlternating_temp4','A_number_IRLSAlternating_2_temp4','A_number_Baseline_temp4','A_number_Exhaustive_temp4');

