Q=[8:-2:0]';  %QoS in dB

save('totalpower5.mat','TotalPower_CBF_temp5','TotalPower_IRLSAlternating_temp5','TotalPower_IRLSAlternating_2_temp5','TotalPower_Baseline_temp5','TotalPower_Exhaustive_temp5');

save('transmitpower5.mat','TransmitPower_CBF_temp5','TransmitPower_IRLSAlternating_temp5','TransmitPower_IRLSAlternating_2_temp5','TransmitPower_Baseline_temp5','TransmitPower_Exhaustive_temp5');

save('activerrh5.mat','A_number_IRLSAlternating_temp5','A_number_IRLSAlternating_2_temp5','A_number_Baseline_temp5','A_number_Exhaustive_temp5');

