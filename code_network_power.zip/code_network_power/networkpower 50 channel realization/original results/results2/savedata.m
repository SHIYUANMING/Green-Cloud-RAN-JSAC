Q=[8:-2:0]';  %QoS in dB

save('totalpower2.mat','TotalPower_CBF_temp2','TotalPower_IRLSAlternating_temp2','TotalPower_IRLSAlternating_2_temp2','TotalPower_Baseline_temp2','TotalPower_Exhaustive_temp2');

save('transmitpower2.mat','TransmitPower_CBF_temp2','TransmitPower_IRLSAlternating_temp2','TransmitPower_IRLSAlternating_2_temp2','TransmitPower_Baseline_temp2','TransmitPower_Exhaustive_temp2');

save('activerrh2.mat','A_number_IRLSAlternating_temp2','A_number_IRLSAlternating_2_temp2','A_number_Baseline_temp2','A_number_Exhaustive_temp2');

