Q=[8:-2:0]';  %QoS in dB

save('totalpower1.mat','TotalPower_CBF_temp1','TotalPower_IRLSAlternating_temp1','TotalPower_IRLSAlternating_2_temp1','TotalPower_Baseline_temp1','TotalPower_Exhaustive_temp1');

save('transmitpower1.mat','TransmitPower_CBF_temp1','TransmitPower_IRLSAlternating_temp1','TransmitPower_IRLSAlternating_2_temp1','TransmitPower_Baseline_temp1','TransmitPower_Exhaustive_temp1');

save('activerrh1.mat','A_number_IRLSAlternating_temp1','A_number_IRLSAlternating_2_temp1','A_number_Baseline_temp1','A_number_Exhaustive_temp1');

