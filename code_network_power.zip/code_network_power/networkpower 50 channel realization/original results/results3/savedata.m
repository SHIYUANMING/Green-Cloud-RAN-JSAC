Q=[8:-2:0]';  %QoS in dB

save('totalpower3.mat','TotalPower_CBF_temp3','TotalPower_IRLSAlternating_temp3','TotalPower_IRLSAlternating_2_temp3','TotalPower_Baseline_temp3','TotalPower_Exhaustive_temp3');

save('transmitpower3.mat','TransmitPower_CBF_temp3','TransmitPower_IRLSAlternating_temp3','TransmitPower_IRLSAlternating_2_temp3','TransmitPower_Baseline_temp3','TransmitPower_Exhaustive_temp3');

save('activerrh3.mat','A_number_IRLSAlternating_temp3','A_number_IRLSAlternating_2_temp3','A_number_Baseline_temp3','A_number_Exhaustive_temp3');

