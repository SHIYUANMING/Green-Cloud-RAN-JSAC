Q=[8:-2:0]';  %QoS in dB
load('TotalPower_IRLSAlternating_1.mat');
load('TotalPower_IRLSAlternating_05.mat');
load('TotalPower_Baseline.mat');
load('TotalPower_CBF.mat');
load('TotalPower_Exhaustive.mat');

TotalPower_IRLSAlternating_1_data=zeros(length(Q),2);
TotalPower_IRLSAlternating_1_data(:,1)=Q;
TotalPower_IRLSAlternating_1_data(:,2)=TotalPower_IRLSAlternating_1;
save('TotalPower_IRLSAlternating_1_data.dat','TotalPower_IRLSAlternating_1_data','-ascii');


TotalPower_IRLSAlternating_05_data=zeros(length(Q),2);
TotalPower_IRLSAlternating_05_data(:,1)=Q;
TotalPower_IRLSAlternating_05_data(:,2)=TotalPower_IRLSAlternating_05;
save('TotalPower_IRLSAlternating_05_data.dat','TotalPower_IRLSAlternating_05_data','-ascii');


TotalPower_Baseline_data=zeros(length(Q),2);
TotalPower_Baseline_data(:,1)=Q;
TotalPower_Baseline_data(:,2)=TotalPower_Baseline;
save('TotalPower_Baseline_data.dat','TotalPower_Baseline_data','-ascii');


TotalPower_CBF_data=zeros(length(Q),2);
TotalPower_CBF_data(:,1)=Q;
TotalPower_CBF_data(:,2)=TotalPower_CBF;
save('TotalPower_CBF_data.dat','TotalPower_CBF_data','-ascii');


TotalPower_Exhaustive_data=zeros(length(Q),2);
TotalPower_Exhaustive_data(:,1)=Q;
TotalPower_Exhaustive_data(:,2)=TotalPower_Exhaustive;
save('TotalPower_Exhaustive_data.dat','TotalPower_Exhaustive_data','-ascii');