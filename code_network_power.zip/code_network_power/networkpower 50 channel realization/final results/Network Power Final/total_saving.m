SU_counter=SU_counter1+SU_counter2+SU_counter3+SU_counter4+SU_counter5;
L=12;
Q=[8:-2:0];
%% active rrh number
A_number_IRLSAlternating_temp=A_number_IRLSAlternating_temp1+A_number_IRLSAlternating_temp2+A_number_IRLSAlternating_temp3+A_number_IRLSAlternating_temp4+A_number_IRLSAlternating_temp5;
A_number_IRLSAlternating_2_temp=A_number_IRLSAlternating_2_temp1+A_number_IRLSAlternating_2_temp2+A_number_IRLSAlternating_2_temp3+A_number_IRLSAlternating_2_temp4+A_number_IRLSAlternating_2_temp5;
A_number_Baseline_temp=A_number_Baseline_temp1+A_number_Baseline_temp2+A_number_Baseline_temp3+A_number_Baseline_temp4+A_number_Baseline_temp5;
A_number_Exhaustive_temp=A_number_Exhaustive_temp1+A_number_Exhaustive_temp2+A_number_Exhaustive_temp3+A_number_Exhaustive_temp4+A_number_Exhaustive_temp5;

A_number_IRLSAlternating_1=A_number_IRLSAlternating_temp/SU_counter;%% with p=1;
A_number_IRLSAlternating_05=A_number_IRLSAlternating_2_temp/SU_counter;%%with p=0.5
A_number_Baseline=A_number_Baseline_temp/SU_counter;
A_number_Exhaustive=A_number_Exhaustive_temp/SU_counter;

%% Total power
TotalPower_CBF_temp=TotalPower_CBF_temp1+TotalPower_CBF_temp2+TotalPower_CBF_temp3+TotalPower_CBF_temp4+TotalPower_CBF_temp5;
TotalPower_IRLSAlternating_temp=TotalPower_IRLSAlternating_temp1+TotalPower_IRLSAlternating_temp2+TotalPower_IRLSAlternating_temp3+TotalPower_IRLSAlternating_temp4+TotalPower_IRLSAlternating_temp5;
TotalPower_IRLSAlternating_2_temp=TotalPower_IRLSAlternating_2_temp1+TotalPower_IRLSAlternating_2_temp2+TotalPower_IRLSAlternating_2_temp3+TotalPower_IRLSAlternating_2_temp4+TotalPower_IRLSAlternating_2_temp5;
TotalPower_Baseline_temp=TotalPower_Baseline_temp1+TotalPower_Baseline_temp2+TotalPower_Baseline_temp3+TotalPower_Baseline_temp4+TotalPower_Baseline_temp5;
TotalPower_Exhaustive_temp=TotalPower_Exhaustive_temp1+TotalPower_Exhaustive_temp2+TotalPower_Exhaustive_temp3+TotalPower_Exhaustive_temp4+TotalPower_Exhaustive_temp5;

TotalPower_CBF=TotalPower_CBF_temp/SU_counter;
TotalPower_IRLSAlternating_1=TotalPower_IRLSAlternating_temp/SU_counter;
TotalPower_IRLSAlternating_05=TotalPower_IRLSAlternating_2_temp/SU_counter;
TotalPower_Baseline=TotalPower_Baseline_temp/SU_counter;
TotalPower_Exhaustive=TotalPower_Exhaustive_temp/SU_counter;

%% Transmit Power
TransmitPower_CBF_temp=TransmitPower_CBF_temp1+TransmitPower_CBF_temp2+TransmitPower_CBF_temp3+TransmitPower_CBF_temp4+TransmitPower_CBF_temp5;
TransmitPower_IRLSAlternating_temp=TransmitPower_IRLSAlternating_temp1+TransmitPower_IRLSAlternating_temp2+TransmitPower_IRLSAlternating_temp3+TransmitPower_IRLSAlternating_temp4+TransmitPower_IRLSAlternating_temp5;
TransmitPower_IRLSAlternating_2_temp=TransmitPower_IRLSAlternating_2_temp1+TransmitPower_IRLSAlternating_2_temp2+TransmitPower_IRLSAlternating_2_temp3+TransmitPower_IRLSAlternating_2_temp4+TransmitPower_IRLSAlternating_2_temp5;
TransmitPower_Baseline_temp=TransmitPower_Baseline_temp1+TransmitPower_Baseline_temp2+TransmitPower_Baseline_temp3+TransmitPower_Baseline_temp4+TransmitPower_Baseline_temp5;
TransmitPower_Exhaustive_temp=TransmitPower_Exhaustive_temp1+TransmitPower_Exhaustive_temp2+TransmitPower_Exhaustive_temp3+TransmitPower_Exhaustive_temp4+TransmitPower_Exhaustive_temp5;

TransmitPower_CBF=TransmitPower_CBF_temp/SU_counter;
TransmitPower_IRLSAlternating_1=TransmitPower_IRLSAlternating_temp/SU_counter;
TransmitPower_IRLSAlternating_05=TransmitPower_IRLSAlternating_2_temp/SU_counter;
TransmitPower_Baseline=TransmitPower_Baseline_temp/SU_counter;
TransmitPower_Exhaustive=TransmitPower_Exhaustive_temp/SU_counter;

%% save data
save('A_number_IRLSAlternating_1.mat','A_number_IRLSAlternating_1');
save('A_number_IRLSAlternating_05.mat','A_number_IRLSAlternating_05');
save('A_number_Baseline.mat','A_number_Baseline');
save('A_number_Exhaustive.mat','A_number_Exhaustive');

save('TotalPower_CBF.mat','TotalPower_CBF');
save('TotalPower_IRLSAlternating_1.mat','TotalPower_IRLSAlternating_1');
save('TotalPower_IRLSAlternating_05.mat','TotalPower_IRLSAlternating_05');
save('TotalPower_Baseline.mat','TotalPower_Baseline');
save('TotalPower_Exhaustive.mat','TotalPower_Exhaustive');

save('TransmitPower_CBF.mat','TransmitPower_CBF');
save('TransmitPower_IRLSAlternating_1.mat','TransmitPower_IRLSAlternating_1');
save('TransmitPower_IRLSAlternating_05.mat','TransmitPower_IRLSAlternating_05');
save('TransmitPower_Baseline.mat','TransmitPower_Baseline');
save('TransmitPower_Exhaustive.mat','TransmitPower_Exhaustive');

%% Plot everage network power consumption%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
plot(Q,TotalPower_CBF,'b-v','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,TotalPower_IRLSAlternating_1,'r-*','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,TotalPower_IRLSAlternating_05,'g-o','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,TotalPower_Baseline,'m-+','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,TotalPower_Exhaustive,'k-d','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin

h=legend('CBF','IRLS for network minimization with p=1','IRLS for network minimization with p=0.5', 'Baseline','Exhaustive Search');  
xlabel('Target SINR [dB]','fontsize',12,'fontweight','b','fontname','helvetica');
ylabel('Average Power Consumption [W]','fontsize',14,'fontweight','b','fontname','helvetica');


%% Plot everage transmit power consumption%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
plot(Q,TransmitPower_CBF,'b-v','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,TransmitPower_IRLSAlternating_1,'r-*','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,TransmitPower_IRLSAlternating_05,'g-o','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,TransmitPower_Baseline,'m-+','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,TransmitPower_Exhaustive,'k-d','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin


h=legend('CBF','IRLS for network minimization with p=1','IRLS for network minimization with p=0.5', 'Baseline','Exhaustive Search');  
xlabel('Target SINR [dB]','fontsize',12,'fontweight','b','fontname','helvetica');
ylabel('Average Transmit Power Consumption [W]','fontsize',14,'fontweight','b','fontname','helvetica');


%% Plot everage number of active RRHs%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
plot(Q,L*ones(length(Q),1),'b-v','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,A_number_IRLSAlternating_1,'r-*','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,A_number_IRLSAlternating_05,'g-o','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,A_number_Baseline,'m-+','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,A_number_Exhaustive,'k-d','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin

h=legend('CBF','IRLS for network minimization with p=1','IRLS for network minimization with p=0.5', 'Baseline','Exhaustive Search');  
xlabel('Target SINR [dB]','fontsize',12,'fontweight','b','fontname','helvetica');
ylabel('Average Number of Active RRHs','fontsize',14,'fontweight','b','fontname','helvetica');