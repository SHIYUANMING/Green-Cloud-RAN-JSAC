
save('userc.mat','user_temp_weightedl2_p1c','user_temp_weightedl2_p2c','user_temp_weightedl1c','user_temp_l1c','user_temp_mdrc','user_temp_exhaustivec');

save('transmitpowerc.mat','transmitpower_temp_weightedl2_p1c','transmitpower_temp_weightedl2_p2c','transmitpower_temp_weightedl1c','transmitpower_temp_l1c','transmitpower_temp_mdrc','transmitpower_temp_exhaustivec');

save('SU_counterc.mat','SU_counterc')