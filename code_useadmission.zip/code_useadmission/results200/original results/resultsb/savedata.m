
save('userb.mat','user_temp_weightedl2_p1b','user_temp_weightedl2_p2b','user_temp_weightedl1b','user_temp_l1b','user_temp_mdrb','user_temp_exhaustiveb');

save('transmitpowerb.mat','transmitpower_temp_weightedl2_p1b','transmitpower_temp_weightedl2_p2b','transmitpower_temp_weightedl1b','transmitpower_temp_l1b','transmitpower_temp_mdrb','transmitpower_temp_exhaustiveb');

save('SU_counterb.mat','SU_counterb')