
save('usere.mat','user_temp_weightedl2_p1e','user_temp_weightedl2_p2e','user_temp_weightedl1e','user_temp_l1e','user_temp_mdre','user_temp_exhaustivee');

save('transmitpowere.mat','transmitpower_temp_weightedl2_p1e','transmitpower_temp_weightedl2_p2e','transmitpower_temp_weightedl1e','transmitpower_temp_l1e','transmitpower_temp_mdre','transmitpower_temp_exhaustivee');

save('SU_countere.mat','SU_countere')