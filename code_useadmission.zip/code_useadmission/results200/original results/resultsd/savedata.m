
save('userd.mat','user_temp_weightedl2_p1d','user_temp_weightedl2_p2d','user_temp_weightedl1d','user_temp_l1d','user_temp_mdrd','user_temp_exhaustived');

save('transmitpowerd.mat','transmitpower_temp_weightedl2_p1d','transmitpower_temp_weightedl2_p2d','transmitpower_temp_weightedl1d','transmitpower_temp_l1d','transmitpower_temp_mdrd','transmitpower_temp_exhaustived');

save('SU_counterd.mat','SU_counterd')