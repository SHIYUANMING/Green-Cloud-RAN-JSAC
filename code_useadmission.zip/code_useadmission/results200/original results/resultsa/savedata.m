Q=[8:-2:0]';  %QoS in dB

save('usera.mat','user_temp_weightedl2_p1a','user_temp_weightedl2_p2a','user_temp_weightedl1a','user_temp_l1a','user_temp_mdra','user_temp_exhaustivea');

save('transmitpowera.mat','transmitpower_temp_weightedl2_p1a','transmitpower_temp_weightedl2_p2a','transmitpower_temp_weightedl1a','transmitpower_temp_l1a','transmitpower_temp_mdra','transmitpower_temp_exhaustivea');

save('SU_countera.mat','SU_countera')