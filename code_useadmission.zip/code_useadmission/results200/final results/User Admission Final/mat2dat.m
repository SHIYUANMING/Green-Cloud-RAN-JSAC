Q=[4:1:10]';  %QoS in dB
%% users 
load('user_weightedl2_p1.mat');
load('user_weightedl2_p05.mat');
load('user_weightedl1.mat');
load('user_l1.mat');
load('user_mdr.mat');
load('user_exhaustive.mat');

user_weightedl2_p1_data=zeros(length(Q),2);
user_weightedl2_p1_data(:,1)=Q;
user_weightedl2_p1_data(:,2)=user_weightedl2_p1;
save('user_weightedl2_p1_data.dat','user_weightedl2_p1_data','-ascii');


user_weightedl2_p05_data=zeros(length(Q),2);
user_weightedl2_p05_data(:,1)=Q;
user_weightedl2_p05_data(:,2)=user_weightedl2_p05;
save('user_weightedl2_p05_data.dat','user_weightedl2_p05_data','-ascii');


user_weightedl1_data=zeros(length(Q),2);
user_weightedl1_data(:,1)=Q;
user_weightedl1_data(:,2)=user_weightedl1;
save('user_weightedl1_data.dat','user_weightedl1_data','-ascii');


user_l1_data=zeros(length(Q),2);
user_l1_data(:,1)=Q;
user_l1_data(:,2)=user_l1;
save('user_l1_data.dat','user_l1_data','-ascii');


user_mdr_data=zeros(length(Q),2);
user_mdr_data(:,1)=Q;
user_mdr_data(:,2)=user_mdr;
save('user_mdr_data.dat','user_mdr_data','-ascii');

user_exhaustive_data=zeros(length(Q),2);
user_exhaustive_data(:,1)=Q;
user_exhaustive_data(:,2)=user_exhaustive;
save('user_exhaustive_data.dat','user_exhaustive_data','-ascii');

%% transmit power
load('transmitpower_weightedl2_p1.mat');
load('transmitpower_weightedl2_p05.mat');
load('transmitpower_weightedl1.mat');
load('transmitpower_l1.mat');
load('transmitpower_mdr.mat');
load('transmitpower_exhaustive.mat');


transmitpower_weightedl2_p1_data=zeros(length(Q),2);
transmitpower_weightedl2_p1_data(:,1)=Q;
transmitpower_weightedl2_p1_data(:,2)=transmitpower_weightedl2_p1;
save('transmitpower_weightedl2_p1_data.dat','transmitpower_weightedl2_p1_data','-ascii');


transmitpower_weightedl2_p05_data=zeros(length(Q),2);
transmitpower_weightedl2_p05_data(:,1)=Q;
transmitpower_weightedl2_p05_data(:,2)=transmitpower_weightedl2_p05;
save('transmitpower_weightedl2_p05_data.dat','transmitpower_weightedl2_p05_data','-ascii');


transmitpower_weightedl1_data=zeros(length(Q),2);
transmitpower_weightedl1_data(:,1)=Q;
transmitpower_weightedl1_data(:,2)=transmitpower_weightedl1;
save('transmitpower_weightedl1_data.dat','transmitpower_weightedl1_data','-ascii');


transmitpower_l1_data=zeros(length(Q),2);
transmitpower_l1_data(:,1)=Q;
transmitpower_l1_data(:,2)=transmitpower_l1;
save('transmitpower_l1_data.dat','transmitpower_l1_data','-ascii');


transmitpower_mdr_data=zeros(length(Q),2);
transmitpower_mdr_data(:,1)=Q;
transmitpower_mdr_data(:,2)=transmitpower_mdr;
save('transmitpower_mdr_data.dat','transmitpower_mdr_data','-ascii');

transmitpower_exhaustive_data=zeros(length(Q),2);
transmitpower_exhaustive_data(:,1)=Q;
transmitpower_exhaustive_data(:,2)=transmitpower_exhaustive;
save('transmitpower_exhaustive_data.dat','transmitpower_exhaustive_data','-ascii');