SU_counter=SU_countera+SU_counterb+SU_counterc+SU_counterd+SU_countere;

Q=[4:1:10];
%% active rrh number
user_temp_weightedl2_p1=user_temp_weightedl2_p1a+user_temp_weightedl2_p1b+user_temp_weightedl2_p1c+user_temp_weightedl2_p1d+user_temp_weightedl2_p1e;
user_temp_weightedl2_p2=user_temp_weightedl2_p2a+user_temp_weightedl2_p2b+user_temp_weightedl2_p2c+user_temp_weightedl2_p2d+user_temp_weightedl2_p2e;
user_temp_weightedl1=user_temp_weightedl1a+user_temp_weightedl1b+user_temp_weightedl1c+user_temp_weightedl1d+user_temp_weightedl1e;
user_temp_l1=user_temp_l1a+user_temp_l1b+user_temp_l1c+user_temp_l1d+user_temp_l1e;
user_temp_mdr=user_temp_mdra+user_temp_mdrb+user_temp_mdrc+user_temp_mdrd+user_temp_mdre;
user_temp_exhaustive=user_temp_exhaustivea+user_temp_exhaustiveb+user_temp_exhaustivec+user_temp_exhaustived+user_temp_exhaustivee;

user_weightedl2_p1=user_temp_weightedl2_p1/SU_counter;
user_weightedl2_p05=user_temp_weightedl2_p2/SU_counter;
user_weightedl1=user_temp_weightedl1/SU_counter;
user_l1=user_temp_l1/SU_counter;
user_mdr=user_temp_mdr/SU_counter;
user_exhaustive=user_temp_exhaustive/SU_counter;


%% Transmit Power
transmitpower_temp_weightedl2_p1=transmitpower_temp_weightedl2_p1a+transmitpower_temp_weightedl2_p1b+transmitpower_temp_weightedl2_p1c+transmitpower_temp_weightedl2_p1d+transmitpower_temp_weightedl2_p1e;
transmitpower_temp_weightedl2_p2=transmitpower_temp_weightedl2_p2a+transmitpower_temp_weightedl2_p2b+transmitpower_temp_weightedl2_p2c+transmitpower_temp_weightedl2_p2d+transmitpower_temp_weightedl2_p2e;
transmitpower_temp_weightedl1=transmitpower_temp_weightedl1a+transmitpower_temp_weightedl1b+transmitpower_temp_weightedl1c+transmitpower_temp_weightedl1d+transmitpower_temp_weightedl1e;
transmitpower_temp_l1=transmitpower_temp_l1a+transmitpower_temp_l1b+transmitpower_temp_l1c+transmitpower_temp_l1d+transmitpower_temp_l1e;
transmitpower_temp_mdr=transmitpower_temp_mdra+transmitpower_temp_mdrb+transmitpower_temp_mdrc+transmitpower_temp_mdrd+transmitpower_temp_mdre;
transmitpower_temp_exhaustive=transmitpower_temp_exhaustivea+transmitpower_temp_exhaustiveb+transmitpower_temp_exhaustivec+transmitpower_temp_exhaustived+transmitpower_temp_exhaustivee;

transmitpower_weightedl2_p1=transmitpower_temp_weightedl2_p1/SU_counter;
transmitpower_weightedl2_p05=transmitpower_temp_weightedl2_p2/SU_counter;
transmitpower_weightedl1=transmitpower_temp_weightedl1/SU_counter;
transmitpower_l1=transmitpower_temp_l1/SU_counter;
transmitpower_mdr=transmitpower_temp_mdr/SU_counter;
transmitpower_exhaustive=transmitpower_temp_exhaustive/SU_counter;

transmitpower_weightedl2_p1=30+10*log10(transmitpower_weightedl2_p1);
transmitpower_weightedl2_p05=30+10*log10(transmitpower_weightedl2_p05);
transmitpower_weightedl1=30+10*log10(transmitpower_weightedl1);
transmitpower_l1=30+10*log10(transmitpower_l1);
transmitpower_mdr=30+10*log10(transmitpower_mdr);
transmitpower_exhaustive=30+10*log10(transmitpower_exhaustive);



%% save data

save('user_weightedl2_p1.mat','user_weightedl2_p1');
save('user_weightedl2_p05.mat','user_weightedl2_p05');
save('user_weightedl1.mat','user_weightedl1');
save('user_l1.mat','user_l1');
save('user_mdr.mat','user_mdr');
save('user_exhaustive.mat','user_exhaustive');


save('transmitpower_weightedl2_p1.mat','transmitpower_weightedl2_p1');
save('transmitpower_weightedl2_p05.mat','transmitpower_weightedl2_p05');
save('transmitpower_weightedl1','transmitpower_weightedl1');
save('transmitpower_l1.mat','transmitpower_l1');
save('transmitpower_mdr.mat','transmitpower_mdr');
save('transmitpower_exhaustive.mat','transmitpower_exhaustive');


%% Plot everage number of users we can support%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
plot(Q,user_weightedl2_p1,'y-v','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,user_weightedl2_p05,'r-*','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,user_weightedl1,'g-o','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,user_l1,'m-+','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,user_mdr,'b-d','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,user_exhaustive,'k-x','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin

h=legend('Weighted L2 Norm with p=1','Weighted L2 Norm with p=0.5','Weighted l1 Norm ', 'L1 Norm','MDR','Exhaustive Search');  
xlabel('Target SINR [dB]','fontsize',12,'fontweight','b','fontname','helvetica');
ylabel('Average Number of Users Admitted','fontsize',14,'fontweight','b','fontname','helvetica');


%% Plot everage transmit power consumption%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
plot(Q,transmitpower_weightedl2_p1,'y-v','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,transmitpower_weightedl2_p05,'r-*','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,transmitpower_weightedl1,'g-o','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,transmitpower_l1,'m-+','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,transmitpower_mdr,'b-d','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,transmitpower_exhaustive,'k-x','LineWidth',1.5, 'MarkerSize',10); %Network power consumptioin

h=legend('Weighted L2 Norm with p=1','Weighted L2 Norm with p=0.5','Weighted l1 Norm ', 'L1 Norm','MDR','Exhaustive Search');  
xlabel('Target SINR [dB]','fontsize',12,'fontweight','b','fontname','helvetica');
ylabel('TransmitPower of Network[dBm]','fontsize',14,'fontweight','b','fontname','helvetica');

